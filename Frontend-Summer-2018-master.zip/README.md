# Frontend-Summer-2018


### Steps to use this Demo Project

----------

1. Download / Clone this Repository on your system. 
1. Open the downloaded folder in a Text Editor - Atom or SublimeText
1. Complete the Ultimate Coding Challenge -- Modify all the codes in the files : Html, CSS, JS. 

### Steps to Submit your Modified Project for the Challenge

-----------

1. Create a new Repo and push the project folder.

```If it is your first time, follow this guide: ```
[Guide](https://help.github.com/articles/create-a-repo/)

2. Copy paste the URL in the form answer.


-------------
